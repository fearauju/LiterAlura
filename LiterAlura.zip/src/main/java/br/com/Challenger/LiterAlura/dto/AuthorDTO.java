package br.com.Challenger.LiterAlura.dto;

public record AuthorDTO(String authorName, Integer birthYear, Integer deathYear) {
}
